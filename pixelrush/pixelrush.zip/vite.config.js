export default {
    base: "/pixelrush/",
};
